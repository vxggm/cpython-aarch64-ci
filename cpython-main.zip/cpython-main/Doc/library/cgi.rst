:mod:`!cgi` --- Common Gateway Interface support
================================================

.. module:: cgi
   :synopsis: Removed in 3.13.
   :deprecated:

.. deprecated-removed:: 3.11 3.13

This module is no longer part of the Python standard library.
It was :ref:`removed in Python 3.13 <whatsnew313-pep594>` after
being deprecated in Python 3.11.  The removal was decided in :pep:`594`.

A fork of the module on PyPI can be used instead: :pypi:`legacy-cgi`.
This package contains copies of the :mod:`!cgi` and :mod:`!cgitb` modules,
which are no longer maintained or supported by the core Python team.

The last version of Python that provided the :mod:`!cgi` module was
`Python 3.12 <https://docs.python.org/3.12/library/cgi.html>`_.
